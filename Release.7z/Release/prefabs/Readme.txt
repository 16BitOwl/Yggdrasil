===========================================================================
Read me file on accepted values in prefabs
===========================================================================

Mode
0 - random
1 - spawn at desired XY position
2 - spawn near desired XY position
3 - relate to another room by name(order is key!)